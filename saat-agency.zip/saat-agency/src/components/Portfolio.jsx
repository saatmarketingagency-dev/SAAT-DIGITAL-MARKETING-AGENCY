import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ExternalLink } from 'lucide-react';

const filters = ['All Work', 'Websites', 'Logo & Brand', 'Social Media'];

const projects = [
  {
    id: 1, cat: 'Websites',
    title: 'Business Landing Page',
    desc: 'Clean, conversion-focused website for a local retail brand',
    tag: 'Website',
    gradient: 'linear-gradient(135deg, #0D0D1F 0%, #1a1a3e 100%)',
    accent: '#00E5A0',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '10px', padding: '20px' }}>
        <div style={{ width: '80%', height: '8px', borderRadius: '4px', background: 'rgba(0,229,160,0.3)' }} />
        <div style={{ width: '60%', height: '6px', borderRadius: '4px', background: 'rgba(255,255,255,0.1)' }} />
        <div style={{ width: '70%', height: '6px', borderRadius: '4px', background: 'rgba(255,255,255,0.08)' }} />
        <div style={{ width: '40%', height: '32px', borderRadius: '8px', background: 'rgba(0,229,160,0.4)', marginTop: '8px' }} />
      </div>
    ),
  },
  {
    id: 2, cat: 'Logo & Brand',
    title: 'Nova Co. Brand Identity',
    desc: 'Complete logo + brand color system for a tech startup',
    tag: 'Logo Design',
    gradient: 'linear-gradient(135deg, #0D0D1F 0%, #1A0D2E 100%)',
    accent: '#7B5EA7',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: '60px', height: '60px', borderRadius: '16px', background: 'linear-gradient(135deg, #7B5EA7, #00E5A0)', margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Syne', fontWeight: 800, fontSize: '24px', color: '#fff' }}>N</div>
          <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.1rem', color: '#EEEEF5', letterSpacing: '0.1em' }}>NOVA CO.</div>
        </div>
      </div>
    ),
  },
  {
    id: 3, cat: 'Social Media',
    title: 'Instagram Page Setup',
    desc: 'Consistent visual theme and content strategy for a fashion brand',
    tag: 'Social Media',
    gradient: 'linear-gradient(135deg, #0D0D1F 0%, #1A1A0D 100%)',
    accent: '#F59E0B',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '4px', width: '100%' }}>
          {[...Array(9)].map((_, i) => (
            <div key={i} style={{ aspectRatio: '1', borderRadius: '4px', background: i % 3 === 0 ? 'rgba(245,158,11,0.3)' : 'rgba(255,255,255,0.06)' }} />
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 4, cat: 'Websites',
    title: 'E-Commerce Store',
    desc: 'Full product listing site for a clothing brand in Rawalpindi',
    tag: 'Website',
    gradient: 'linear-gradient(135deg, #0D0D1F 0%, #1A0D0D 100%)',
    accent: '#EF4444',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px', flexDirection: 'column', gap: '8px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', width: '100%' }}>
          {[...Array(4)].map((_, i) => (
            <div key={i} style={{ height: '50px', borderRadius: '8px', background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.2)', display: 'flex', alignItems: 'flex-end', padding: '6px' }}>
              <div style={{ fontFamily: 'Syne', fontSize: '0.6rem', color: 'rgba(239,68,68,0.7)', fontWeight: 600 }}>PKR 2,400</div>
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 5, cat: 'Logo & Brand',
    title: 'Zephyr Corporate Branding',
    desc: 'Professional mark with business card and stationery design',
    tag: 'Brand Identity',
    gradient: 'linear-gradient(135deg, #06060F 0%, #0D1A1A 100%)',
    accent: '#06B6D4',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: '50px', height: '50px', borderRadius: '50%', border: '3px solid #06B6D4', margin: '0 auto 10px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'Syne', fontWeight: 800, fontSize: '20px', color: '#06B6D4' }}>Z</div>
          <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.9rem', color: '#EEEEF5', letterSpacing: '0.15em' }}>ZEPHYR</div>
        </div>
      </div>
    ),
  },
  {
    id: 6, cat: 'Social Media',
    title: 'Restaurant Social Campaign',
    desc: 'Monthly content plan and graphic templates for a food business',
    tag: 'Social Media',
    gradient: 'linear-gradient(135deg, #0D0D1F 0%, #1A0F0D 100%)',
    accent: '#F97316',
    visual: (
      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px' }}>
        <div style={{ width: '100%' }}>
          {[0.8, 0.6, 0.9, 0.5].map((w, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <div style={{ width: '24px', height: '24px', borderRadius: '50%', background: 'rgba(249,115,22,0.3)', flexShrink: 0 }} />
              <div style={{ flex: 1, height: '6px', borderRadius: '3px', background: 'rgba(249,115,22,0.2)', width: `${w * 100}%` }} />
            </div>
          ))}
        </div>
      </div>
    ),
  },
];

export default function Portfolio() {
  const [activeFilter, setActiveFilter] = useState('All Work');
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  const filtered = activeFilter === 'All Work' ? projects : projects.filter(p => p.cat === activeFilter);

  return (
    <section id="portfolio" className="relative py-28 px-6" style={{ zIndex: 1 }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12"
        >
          <div className="section-label mb-4">Our Work</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            A Glimpse at What{' '}
            <span className="gradient-text">We Deliver</span>
          </h2>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', maxWidth: '480px', margin: '12px auto 0', fontSize: '1rem' }}>
            Sample projects across Pakistan and worldwide — for illustration purposes.
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.2 }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className="px-5 py-2 rounded-full text-sm transition-all duration-300"
              style={{
                fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', letterSpacing: '0.06em',
                background: activeFilter === f ? 'rgba(0,229,160,0.12)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${activeFilter === f ? 'rgba(0,229,160,0.5)' : 'rgba(30,30,63,0.8)'}`,
                color: activeFilter === f ? '#00E5A0' : '#7C7C9D',
                cursor: 'pointer',
              }}
            >
              {f}
            </button>
          ))}
        </motion.div>

        {/* Grid */}
        <motion.div layout className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence mode="popLayout">
            {filtered.map((proj, i) => (
              <motion.div
                key={proj.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
                className="group rounded-2xl overflow-hidden cursor-pointer"
                style={{ background: proj.gradient, border: `1px solid rgba(30,30,63,0.8)`, transition: 'all 0.4s ease' }}
                whileHover={{ y: -6, boxShadow: `0 20px 60px rgba(0,0,0,0.5), 0 0 30px ${proj.accent}18` }}
              >
                {/* Visual placeholder */}
                <div className="h-44 relative overflow-hidden" style={{ borderBottom: `1px solid rgba(30,30,63,0.6)` }}>
                  {proj.visual}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center"
                    style={{ background: 'rgba(6,6,15,0.5)' }}>
                    <ExternalLink size={20} style={{ color: proj.accent }} />
                  </div>
                </div>

                {/* Info */}
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-3 py-1 rounded-full text-xs font-bold"
                      style={{ fontFamily: 'Syne', background: `${proj.accent}15`, border: `1px solid ${proj.accent}30`, color: proj.accent, letterSpacing: '0.06em' }}>
                      {proj.tag}
                    </span>
                  </div>
                  <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1rem', color: '#EEEEF5', marginBottom: '6px' }}>{proj.title}</h3>
                  <p style={{ fontFamily: 'DM Sans', fontSize: '0.82rem', color: '#7C7C9D', lineHeight: 1.55 }}>{proj.desc}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center mt-8"
          style={{ fontFamily: 'DM Sans', fontSize: '0.8rem', color: '#7C7C9D' }}
        >
          ✨ Sample Projects — For Illustration Purposes
        </motion.p>
      </div>
    </section>
  );
}
