import { motion } from 'framer-motion';
import { MapPin, Mail, Phone } from 'lucide-react';

// Inline SVG social icons since lucide-react v0.383 doesn't export brand icons
const InstagramIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/>
  </svg>
);
const YoutubeIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22.54 6.42a2.78 2.78 0 0 0-1.95-1.96C18.88 4 12 4 12 4s-6.88 0-8.59.46A2.78 2.78 0 0 0 1.46 6.42 29 29 0 0 0 1 12a29 29 0 0 0 .46 5.58 2.78 2.78 0 0 0 1.95 1.96C5.12 20 12 20 12 20s6.88 0 8.59-.46a2.78 2.78 0 0 0 1.95-1.96A29 29 0 0 0 23 12a29 29 0 0 0-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02"/>
  </svg>
);
const FacebookIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
  </svg>
);
const LinkedinIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>
  </svg>
);

const quickLinks = [
  { label: 'The Problem', href: '#problem' },
  { label: 'Our Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'How We Work', href: '#process' },
  { label: 'Contact', href: '#contact' },
];

const socials = [
  { icon: FacebookIcon, href: '#', label: 'Facebook' },
  { icon: InstagramIcon, href: 'https://www.instagram.com/saatmarketingagency', label: 'Instagram' },
  { icon: LinkedinIcon, href: '#', label: 'LinkedIn' },
  { icon: YoutubeIcon, href: '#', label: 'YouTube' },
];

export default function Footer() {
  const scrollTo = (href) => {
    if (href === '#') { window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="relative" style={{ background: '#06060F', borderTop: '1px solid rgba(30,30,63,0.6)', zIndex: 1 }}>
      <div className="max-w-6xl mx-auto px-6 pt-16 pb-8">
        <div className="grid md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-xl overflow-hidden" style={{ border: '1.5px solid rgba(0,229,160,0.4)' }}>
                <img src="https://brine-2010.github.io/SAAT/Saat-icon.jpg" alt="SAAT" className="w-full h-full object-cover"
                  onError={(e) => { e.target.style.display = 'none'; }}
                />
              </div>
              <span style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.3rem', color: '#EEEEF5' }}>SAAT</span>
            </div>
            <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '0.9rem', lineHeight: 1.7, maxWidth: '320px' }}>
              We blend expertise in marketing, development, and branding to build revenue-producing engines for our clients.
            </p>
            <div className="flex gap-3 mt-6">
              {socials.map(({ icon: Icon, href, label }) => (
                <motion.a
                  key={label} href={href} target="_blank" rel="noopener noreferrer"
                  whileHover={{ scale: 1.15, y: -2 }}
                  className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-300"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(30,30,63,0.8)' }}
                  aria-label={label}
                >
                  <Icon size={15} style={{ color: '#7C7C9D' }} />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.85rem', color: '#EEEEF5', letterSpacing: '0.08em', marginBottom: '16px' }}>
              QUICK LINKS
            </h4>
            <ul className="space-y-3">
              {quickLinks.map(({ label, href }) => (
                <li key={label}>
                  <button
                    onClick={() => scrollTo(href)}
                    style={{ fontFamily: 'DM Sans', fontSize: '0.9rem', color: '#7C7C9D', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
                    className="hover:text-[#00E5A0] transition-colors"
                  >
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.85rem', color: '#EEEEF5', letterSpacing: '0.08em', marginBottom: '16px' }}>
              CONTACT
            </h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-[#7C7C9D]" style={{ fontFamily: 'DM Sans', fontSize: '0.88rem' }}>
                <MapPin size={13} style={{ color: '#00E5A0', flexShrink: 0 }} /> Rawalpindi, Pakistan
              </li>
              <li>
                <a href="mailto:saatmarketingagency@gmail.com"
                  className="flex items-center gap-2 hover:text-[#00E5A0] transition-colors"
                  style={{ fontFamily: 'DM Sans', fontSize: '0.85rem', color: '#7C7C9D', textDecoration: 'none' }}>
                  <Mail size={13} style={{ color: '#00E5A0', flexShrink: 0 }} /> saatmarketingagency@gmail.com
                </a>
              </li>
              <li>
                <a href="tel:+923138586949"
                  className="flex items-center gap-2 hover:text-[#00E5A0] transition-colors"
                  style={{ fontFamily: 'DM Sans', fontSize: '0.88rem', color: '#7C7C9D', textDecoration: 'none' }}>
                  <Phone size={13} style={{ color: '#00E5A0', flexShrink: 0 }} /> +92 313 8586949
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderTop: '1px solid rgba(30,30,63,0.6)' }}>
          <span style={{ fontFamily: 'DM Sans', fontSize: '0.82rem', color: '#7C7C9D' }}>
            © 2026 SAAT Digital Marketing Agency. All Rights Reserved.
          </span>
          <span style={{ fontFamily: 'Syne', fontSize: '0.72rem', color: '#7C7C9D', letterSpacing: '0.08em' }}>
            RAWALPINDI, PAKISTAN • EST. 2024
          </span>
        </div>
      </div>
    </footer>
  );
}
