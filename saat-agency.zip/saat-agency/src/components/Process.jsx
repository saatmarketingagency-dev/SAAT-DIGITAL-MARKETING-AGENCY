import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Phone, Target, ClipboardList, Rocket, Wrench } from 'lucide-react';

const steps = [
  { icon: Phone, num: '01', title: 'Contact Us', desc: 'Reach out via form, WhatsApp, or email. We respond within 24 hours — no waiting, no runaround.' },
  { icon: Target, num: '02', title: 'Understand Your Business', desc: 'We learn your goals, audience, and what makes your business unique. Deep discovery, zero assumptions.' },
  { icon: ClipboardList, num: '03', title: 'Create Strategy', desc: 'We design a custom digital plan tailored to your exact business needs, backed by research and data.' },
  { icon: Rocket, num: '04', title: 'Deliver the Work', desc: 'Fast, quality delivery with revisions until you\'re completely satisfied. We don\'t ship until it\'s right.' },
  { icon: Wrench, num: '05', title: 'Support & Improve', desc: 'We stay with you. Ongoing support, updates, and continuous growth — because our job doesn\'t end at launch.' },
];

export default function Process() {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="process" className="relative py-28 px-6 overflow-hidden" style={{ zIndex: 1 }}>
      {/* BG line */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(0,229,160,0.3), transparent)' }} />

      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-16"
        >
          <div className="section-label mb-4">How We Work</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            Simple, Transparent{' '}
            <span className="gradient-text">Process</span>
          </h2>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', maxWidth: '460px', margin: '16px auto 0', fontSize: '1.05rem' }}>
            Designed to get you results without the hassle.
          </p>
        </motion.div>

        <div className="relative">
          {/* Connector line – desktop only */}
          <div className="hidden lg:block absolute top-[52px] left-[calc(10%+24px)] right-[calc(10%+24px)] h-px"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(0,229,160,0.2) 20%, rgba(0,229,160,0.2) 80%, transparent)' }} />

          <div className="grid lg:grid-cols-5 gap-6">
            {steps.map(({ icon: Icon, num, title, desc }, i) => (
              <motion.div
                key={num}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: i * 0.12 + 0.2, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="flex flex-col items-center text-center group"
              >
                {/* Circle */}
                <div className="relative mb-6">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center relative z-10 transition-all duration-300 group-hover:scale-110"
                    style={{ background: 'linear-gradient(135deg, rgba(0,229,160,0.15), rgba(123,94,167,0.15))', border: '1px solid rgba(0,229,160,0.35)' }}>
                    <Icon size={20} style={{ color: '#00E5A0' }} />
                  </div>
                  {/* Pulse ring */}
                  <div className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{ animation: 'pulse-ring 1.5s ease-out infinite', border: '1px solid rgba(0,229,160,0.3)' }} />
                </div>

                <div className="mb-2"
                  style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '0.75rem', letterSpacing: '0.12em', color: '#00E5A0' }}>
                  STEP {num}
                </div>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1rem', color: '#EEEEF5', marginBottom: '8px' }}>{title}</h3>
                <p style={{ fontFamily: 'DM Sans', fontSize: '0.82rem', color: '#7C7C9D', lineHeight: 1.65 }}>{desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
