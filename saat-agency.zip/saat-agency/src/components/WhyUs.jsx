import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Zap, DollarSign, Layers, BarChart2 } from 'lucide-react';

const reasons = [
  {
    icon: Zap,
    title: 'Fast Delivery',
    desc: 'We respect your time. Most projects are delivered within agreed deadlines — no endless waiting, no vague timelines.',
    color: '#F59E0B',
  },
  {
    icon: DollarSign,
    title: 'Affordable Pricing',
    desc: 'Premium quality without the premium price tag. Enterprise-level results on a budget that makes sense.',
    color: '#00E5A0',
  },
  {
    icon: Layers,
    title: 'Modern Designs',
    desc: 'We don\'t do outdated templates. Every design is custom, contemporary, and built to make your brand look like a market leader.',
    color: '#7B5EA7',
  },
  {
    icon: BarChart2,
    title: 'Results-Focused',
    desc: 'We measure everything. Our goal isn\'t just beautiful work — it\'s work that actually brings customers and grows your revenue.',
    color: '#EF4444',
  },
];

export default function WhyUs() {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="why" className="relative py-28 px-6" style={{ zIndex: 1 }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-16"
        >
          <div className="section-label mb-4">Why Choose SAAT</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            There Are Agencies Everywhere.{' '}
            <span className="gradient-text">Here's the Difference.</span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
          {reasons.map(({ icon: Icon, title, desc, color }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 30 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: i * 0.12 + 0.2, duration: 0.6 }}
              className="card p-7 group flex gap-5"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                  style={{ background: `${color}12`, border: `1px solid ${color}30` }}>
                  <Icon size={22} style={{ color }} />
                </div>
              </div>
              <div>
                <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.05rem', color: '#EEEEF5', marginBottom: '8px' }}>{title}</h3>
                <p style={{ fontFamily: 'DM Sans', fontSize: '0.9rem', color: '#7C7C9D', lineHeight: 1.65 }}>{desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
