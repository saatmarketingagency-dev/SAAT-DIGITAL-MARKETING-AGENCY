import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, TrendingUp, Globe, Palette } from 'lucide-react';

const badges = [
  { icon: TrendingUp, label: 'Marketing Strategy' },
  { icon: Globe, label: 'Web Development' },
  { icon: Palette, label: 'Brand Design' },
];

const ticker = [
  'DIGITAL GROWTH', 'WEBSITES', 'BRANDING', 'WEB MANAGEMENT',
  'SOCIAL MEDIA', 'SEO', 'GRAPHIC DESIGN', 'CONTENT STRATEGY',
];

export default function Hero() {
  const scrollTo = (id) => document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <section className="relative min-h-screen flex flex-col overflow-hidden" style={{ zIndex: 1 }}>
      {/* Gradient orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 -left-32 w-[600px] h-[600px] rounded-full opacity-20"
          style={{ background: 'radial-gradient(circle, #00E5A0 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div className="absolute top-1/3 -right-32 w-[500px] h-[500px] rounded-full opacity-15"
          style={{ background: 'radial-gradient(circle, #7B5EA7 0%, transparent 70%)', filter: 'blur(60px)' }} />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] opacity-10"
          style={{ background: 'radial-gradient(ellipse, #00E5A0 0%, transparent 70%)', filter: 'blur(80px)' }} />
      </div>

      {/* Main content */}
      <div className="relative flex-1 flex flex-col items-center justify-center px-6 pt-32 pb-20 text-center max-w-6xl mx-auto w-full">

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="inline-flex items-center gap-2 mb-8 px-4 py-2 rounded-full"
          style={{ border: '1px solid rgba(0,229,160,0.3)', background: 'rgba(0,229,160,0.06)' }}
        >
          <Sparkles size={14} style={{ color: '#00E5A0' }} />
          <span style={{ fontFamily: 'Syne', fontSize: '0.78rem', fontWeight: 600, color: '#00E5A0', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Premier Digital Agency in Pakistan
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
          style={{ fontFamily: 'Syne', fontWeight: 800, lineHeight: 1.05, letterSpacing: '-0.02em' }}
          className="text-5xl md:text-7xl lg:text-8xl text-[#EEEEF5] mb-4"
        >
          Build Your
          <br />
          <span className="gradient-text">Digital Presence.</span>
        </motion.h1>

        {/* Sub */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          style={{ fontFamily: 'DM Sans', fontSize: '1.15rem', fontWeight: 300, lineHeight: 1.7 }}
          className="text-[#7C7C9D] max-w-2xl mt-4 mb-10"
        >
          Most businesses lose money every day because they're invisible online.{' '}
          <strong style={{ color: '#EEEEF5', fontWeight: 500 }}>SAAT changes that.</strong>{' '}
          We help businesses grow with websites, design, and full digital management.
        </motion.p>

        {/* CTA Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.65 }}
          className="flex flex-col sm:flex-row items-center gap-4 mb-16"
        >
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => scrollTo('#contact')}
            className="btn-primary"
          >
            Start Your Project <ArrowRight size={16} />
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => scrollTo('#portfolio')}
            className="btn-ghost"
          >
            View Our Work
          </motion.button>
        </motion.div>

        {/* Service Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="flex flex-wrap justify-center gap-3"
        >
          {badges.map(({ icon: Icon, label }, i) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.85 + i * 0.1 }}
              className="flex items-center gap-2 px-4 py-2 rounded-full"
              style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', fontFamily: 'DM Sans', fontSize: '0.85rem', color: '#7C7C9D' }}
            >
              <Icon size={14} style={{ color: '#00E5A0' }} />
              {label}
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Stats row */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0, duration: 0.7 }}
        className="relative px-6 pb-6 max-w-6xl mx-auto w-full"
      >
        <div className="grid grid-cols-3 gap-4 p-6 rounded-2xl"
          style={{ background: 'rgba(17,17,40,0.6)', border: '1px solid rgba(30,30,63,0.8)', backdropFilter: 'blur(20px)' }}>
          {[
            { val: '100%', label: 'Client Satisfaction' },
            { val: 'ROI', label: 'Driven Results' },
            { val: '24hr', label: 'Priority Support' },
          ].map(({ val, label }) => (
            <div key={label} className="text-center">
              <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(1.5rem,3vw,2.5rem)', color: '#00E5A0' }}>{val}</div>
              <div style={{ fontFamily: 'DM Sans', fontSize: '0.8rem', color: '#7C7C9D', marginTop: '4px' }}>{label}</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Ticker */}
      <div className="ticker-wrap py-4 border-t border-b" style={{ borderColor: 'rgba(30,30,63,0.6)', background: 'rgba(13,13,31,0.5)' }}>
        <div className="ticker-track">
          {[...ticker, ...ticker].map((item, i) => (
            <span key={i} className="flex items-center gap-4 mx-6"
              style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.12em', color: '#7C7C9D' }}>
              {item}
              <span style={{ color: '#00E5A0', fontSize: '1rem' }}>•</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
