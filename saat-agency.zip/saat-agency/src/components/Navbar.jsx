import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const links = [
  { label: 'About Us', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Portfolio', href: '#portfolio' },
  { label: 'Process', href: '#process' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNav = (href) => {
    setOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
        style={{
          background: scrolled ? 'rgba(6,6,15,0.85)' : 'transparent',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          borderBottom: scrolled ? '1px solid rgba(30,30,63,0.6)' : '1px solid transparent',
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          {/* Logo */}
          <motion.a
            href="#"
            whileHover={{ scale: 1.03 }}
            className="flex items-center gap-3"
            onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
          >
            <div className="relative w-10 h-10 rounded-xl overflow-hidden flex-shrink-0"
              style={{ border: '1.5px solid rgba(0,229,160,0.4)' }}>
              <img
                src="https://brine-2010.github.io/SAAT/Saat-icon.jpg"
                alt="SAAT"
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextElementSibling.style.display = 'flex';
                }}
              />
              <div className="hidden w-full h-full items-center justify-center"
                style={{ background: 'linear-gradient(135deg,#00E5A0,#7B5EA7)', display: 'none' }}>
                <span style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '14px', color: '#06060F' }}>S</span>
              </div>
            </div>
            <span style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.25rem', color: '#EEEEF5' }}>
              SAAT
            </span>
          </motion.a>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <button
                key={link.href}
                onClick={() => handleNav(link.href)}
                style={{ fontFamily: 'Syne', fontWeight: 500, fontSize: '0.875rem', letterSpacing: '0.04em', background: 'none', border: 'none', cursor: 'pointer' }}
                className="text-[#7C7C9D] hover:text-[#00E5A0] transition-colors duration-300 uppercase tracking-wider"
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* CTA + Mobile Toggle */}
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => handleNav('#contact')}
              className="hidden md:flex btn-primary text-sm"
            >
              Get Proposal
            </motion.button>
            <button
              className="md:hidden text-[#EEEEF5] p-2"
              onClick={() => setOpen(!open)}
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed top-[72px] left-0 right-0 z-40 px-6 py-4"
            style={{ background: 'rgba(13,13,31,0.98)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(30,30,63,0.8)' }}
          >
            <div className="flex flex-col gap-2">
              {links.map((link, i) => (
                <motion.button
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  onClick={() => handleNav(link.href)}
                  className="text-left py-3 px-4 rounded-xl text-[#EEEEF5] hover:text-[#00E5A0] hover:bg-[rgba(0,229,160,0.05)] transition-all"
                  style={{ fontFamily: 'Syne', fontWeight: 500, fontSize: '0.95rem', background: 'none', border: 'none', cursor: 'pointer' }}
                >
                  {link.label}
                </motion.button>
              ))}
              <button onClick={() => handleNav('#contact')} className="btn-primary mt-2 justify-center">
                Get Proposal
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
