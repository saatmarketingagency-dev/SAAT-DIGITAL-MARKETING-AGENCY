import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';

export default function WhatsAppButton() {
  return (
    <motion.a
      href="https://wa.me/923138586949?text=Hi%20SAAT!%20I%20found%20you%20online%20and%20would%20like%20to%20discuss%20my%20project."
      target="_blank"
      rel="noopener noreferrer"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1.8, type: 'spring', stiffness: 300 }}
      whileHover={{ scale: 1.12 }}
      whileTap={{ scale: 0.95 }}
      className="fixed z-50 flex items-center justify-center rounded-full"
      style={{
        bottom: '24px',
        right: '24px',
        width: '52px',
        height: '52px',
        background: 'linear-gradient(135deg, #25D366, #128C7E)',
        boxShadow: '0 8px 30px rgba(37,211,102,0.4)',
        border: 'none',
        cursor: 'pointer',
      }}
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={24} style={{ color: '#fff' }} />

      {/* Pulse ring */}
      <span className="absolute inset-0 rounded-full" style={{ animation: 'wa-pulse 2s ease-out infinite', border: '2px solid rgba(37,211,102,0.5)' }} />

      <style>{`
        @keyframes wa-pulse {
          0% { transform: scale(1); opacity: 0.8; }
          100% { transform: scale(1.6); opacity: 0; }
        }
      `}</style>
    </motion.a>
  );
}
