import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { MapPin, Users, Award, Lightbulb } from 'lucide-react';

const pillars = [
  { icon: Lightbulb, title: 'Deep Creativity', desc: 'Every solution is crafted with design thinking and brand storytelling at its core.' },
  { icon: Award, title: 'Data-Driven', desc: 'We combine creativity with analytics so every decision moves the needle.' },
  { icon: Users, title: 'Team of Specialists', desc: 'Built by four industry experts — each a master of their discipline.' },
  { icon: MapPin, title: 'Pakistan-Based', desc: 'Local knowledge, global standards. Based in Rawalpindi, serving worldwide.' },
];

export default function About() {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="about" className="relative py-28 px-6 overflow-hidden" style={{ zIndex: 1 }}>
      {/* bg accent */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(0,229,160,0.3), transparent)' }} />
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full h-px" style={{ background: 'linear-gradient(90deg, transparent, rgba(0,229,160,0.3), transparent)' }} />
      </div>

      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left – text */}
          <motion.div
            ref={ref}
            initial={{ opacity: 0, x: -40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="section-label mb-4">SAAT Studio</div>
            <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,4vw,3.2rem)', color: '#EEEEF5', lineHeight: 1.12, letterSpacing: '-0.02em' }}>
              Empowering Brands in{' '}
              <span className="gradient-text">the Cyberspace</span>
            </h2>
            <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '1.05rem', lineHeight: 1.75, marginTop: '20px' }}>
              Located right here in <strong style={{ color: '#EEEEF5' }}>Rawalpindi, Pakistan</strong> — SAAT was built by four industry specialists to bridge the gap between businesses and the modern digital world.
            </p>
            <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '1.05rem', lineHeight: 1.75, marginTop: '12px' }}>
              We combine deep creativity with data-driven strategies. From local SEO to complete web architecture, we provide honest, transparent solutions that keep you ahead of the competition.
            </p>

            <div className="mt-10 p-6 rounded-2xl" style={{ background: 'rgba(0,229,160,0.04)', border: '1px solid rgba(0,229,160,0.15)' }}>
              <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1rem', color: '#00E5A0', marginBottom: '10px' }}>Why We Started SAAT</h3>
              <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '0.92rem', lineHeight: 1.7 }}>
                We saw too many great businesses failing online — not because of bad products, but because of bad digital presence. SAAT exists to fix that. We bring enterprise-level marketing to businesses of all sizes, with pricing that makes sense and results you can measure.
              </p>
            </div>
          </motion.div>

          {/* Right – pillars grid */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-2 gap-4"
          >
            {pillars.map(({ icon: Icon, title, desc }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.25 + i * 0.1 }}
                className="p-5 rounded-2xl card group"
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 transition-all duration-300 group-hover:scale-110"
                  style={{ background: 'rgba(0,229,160,0.1)', border: '1px solid rgba(0,229,160,0.2)' }}>
                  <Icon size={18} style={{ color: '#00E5A0' }} />
                </div>
                <h4 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.95rem', color: '#EEEEF5', marginBottom: '6px' }}>{title}</h4>
                <p style={{ fontFamily: 'DM Sans', fontSize: '0.82rem', color: '#7C7C9D', lineHeight: 1.6 }}>{desc}</p>
              </motion.div>
            ))}

            {/* Big stat */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.55 }}
              className="col-span-2 p-6 rounded-2xl text-center"
              style={{ background: 'linear-gradient(135deg, rgba(0,229,160,0.08), rgba(123,94,167,0.08))', border: '1px solid rgba(0,229,160,0.2)' }}
            >
              <div style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '3rem', color: '#00E5A0' }}>100%</div>
              <div style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '0.9rem', marginTop: '4px' }}>Client satisfaction rate — every project, every time</div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
