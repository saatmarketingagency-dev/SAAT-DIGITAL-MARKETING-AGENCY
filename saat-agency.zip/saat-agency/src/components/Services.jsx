import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import {
  TrendingUp, Globe, Search, Smartphone, Palette,
  ArrowRight, X, CheckCircle2, ChevronRight
} from 'lucide-react';

const services = [
  {
    id: 'marketing',
    icon: TrendingUp,
    color: '#00E5A0',
    title: 'Marketing Strategy',
    subtitle: 'The Blueprint for Your Success',
    short: 'Data-driven roadmaps tailored to your goals — every decision backed by analysis, not guesswork.',
    what: 'A custom, end-to-end marketing roadmap built around your specific industry, audience, and revenue goals. We combine competitor research, audience profiling, and channel selection into one clear strategy you can act on immediately.',
    deliverables: [
      'In-depth target audience analysis',
      'Competitor landscape research',
      'Custom marketing roadmap & calendar',
      'Budget allocation recommendations',
      'KPI setting & performance benchmarks',
      'Channel strategy (SEO, social, ads)',
      'Monthly review & strategy refinement',
    ],
  },
  {
    id: 'web',
    icon: Globe,
    color: '#7B5EA7',
    title: 'Web Design & Development',
    subtitle: 'Your Digital Storefront, Built to Perform',
    short: 'Responsive, fast-loading, and visually captivating websites that convert visitors into customers.',
    what: 'From sleek landing pages to full e-commerce stores, SAAT creates websites that are fast, mobile-optimized, and search-engine-friendly. We don\'t use cheap templates — every site is custom-designed to match your brand.',
    deliverables: [
      '100% custom design — no templates',
      'Fully responsive (mobile & desktop)',
      'SEO-optimized from day one',
      'Fast loading speed (under 3 seconds)',
      'Contact forms & WhatsApp integration',
      'Technical maintenance & updates',
      'Security monitoring & bug fixes',
      'Post-launch support included',
    ],
  },
  {
    id: 'seo',
    icon: Search,
    color: '#00E5A0',
    title: 'Search Engine Optimization',
    subtitle: 'Get Found Where It Matters Most',
    short: 'Cutting-edge techniques to rank you higher on Google and drive organic traffic that converts.',
    what: 'A complete SEO strategy covering your entire online presence — from technical site health to content and authority. We audit your current standing, fix what\'s broken, and build a roadmap to page one.',
    deliverables: [
      'Full technical SEO audit & fixes',
      'In-depth keyword research & targeting',
      'On-page optimization (titles, meta, structure)',
      'High-quality backlink building',
      'Local SEO for Pakistan-based searches',
      'Google Search Console & Analytics setup',
      'Monthly ranking & traffic reports',
      'Ongoing content optimization',
    ],
  },
  {
    id: 'social',
    icon: Smartphone,
    color: '#7B5EA7',
    title: 'Social Media Handling',
    subtitle: 'Building Communities & Brand Loyalty',
    short: 'End-to-end management of your platforms — content, scheduling, community, and growth.',
    what: 'We handle strategy, content creation, graphic design, captions, hashtag research, and monthly analytics reports — everything needed to grow your online presence across Instagram, Facebook, TikTok, and more.',
    deliverables: [
      'Custom content strategy for your niche',
      'Professional branded graphics for every post',
      'Engaging captions + targeted hashtags',
      'Scheduled & consistent posting',
      'Community engagement & comment replies',
      'Stories, Reels, and highlight covers',
      'Monthly performance analytics report',
      'Content calendar & planning',
    ],
  },
  {
    id: 'branding',
    icon: Palette,
    color: '#00E5A0',
    title: 'Brand Identity & Graphic Design',
    subtitle: 'Visual Storytelling That Captivates',
    short: 'Stunning visuals and dynamic motion graphics that capture attention and define your brand.',
    what: 'From logo design and complete brand identity kits to social media graphics, we produce every visual asset your brand needs to look premium and unforgettable.',
    deliverables: [
      '100% original, custom designs',
      'Logo design & complete brand identity',
      'Social media graphics & templates',
      'Thumbnail & banner designs',
      'High-resolution files in all formats',
      'Brand color palette & typography guide',
      'Full ownership of all creative files',
      'Video editing',
    ],
  },
];

function ServiceModal({ service, onClose }) {
  const Icon = service.icon;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(6,6,15,0.85)', backdropFilter: 'blur(12px)' }}
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.92, y: 30 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto chatbot-window p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
              style={{ background: `${service.color}18`, border: `1px solid ${service.color}40` }}>
              <Icon size={22} style={{ color: service.color }} />
            </div>
            <div>
              <h3 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: '1.3rem', color: '#EEEEF5' }}>{service.title}</h3>
              <p style={{ fontFamily: 'DM Sans', fontSize: '0.85rem', color: '#7C7C9D' }}>{service.subtitle}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#7C7C9D] hover:text-[#EEEEF5] transition-colors p-1">
            <X size={20} />
          </button>
        </div>

        <div className="mb-6 p-5 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(30,30,63,0.8)' }}>
          <div className="section-label mb-2">What We Build</div>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '0.95rem', lineHeight: 1.7 }}>{service.what}</p>
        </div>

        <div className="mb-8">
          <div className="section-label mb-4">What You Get</div>
          <div className="space-y-3">
            {service.deliverables.map((d) => (
              <div key={d} className="flex items-start gap-3">
                <CheckCircle2 size={15} style={{ color: service.color, flexShrink: 0, marginTop: '2px' }} />
                <span style={{ fontFamily: 'DM Sans', fontSize: '0.92rem', color: '#EEEEF5' }}>{d}</span>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => { onClose(); document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' }); }}
          className="btn-primary w-full justify-center"
        >
          Get Started with {service.title.split(' ')[0]} <ArrowRight size={16} />
        </button>
      </motion.div>
    </motion.div>
  );
}

export default function Services() {
  const [active, setActive] = useState(null);
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="services" className="relative py-28 px-6" style={{ zIndex: 1 }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-16"
        >
          <div className="section-label mb-4">Core Expertise</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            Everything You Need to{' '}
            <span className="gradient-text">Dominate Online</span>
          </h2>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', maxWidth: '500px', margin: '16px auto 0', fontSize: '1.05rem' }}>
            Click any service to explore what's included and the benefits for your business.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((svc, i) => {
            const Icon = svc.icon;
            return (
              <motion.div
                key={svc.id}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: i * 0.1 + 0.2, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                onClick={() => setActive(svc)}
                className="card p-6 cursor-pointer group relative overflow-hidden"
              >
                {/* Glow background */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{ background: `radial-gradient(circle at 30% 30%, ${svc.color}08, transparent 70%)` }} />

                <div className="relative">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300"
                    style={{ background: `${svc.color}12`, border: `1px solid ${svc.color}30` }}>
                    <Icon size={22} style={{ color: svc.color }} />
                  </div>

                  <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1.05rem', color: '#EEEEF5', marginBottom: '10px' }}>
                    {svc.title}
                  </h3>
                  <p style={{ fontFamily: 'DM Sans', fontSize: '0.88rem', color: '#7C7C9D', lineHeight: 1.65, marginBottom: '20px' }}>
                    {svc.short}
                  </p>

                  <div className="flex items-center gap-2 text-sm font-semibold transition-all duration-300 group-hover:gap-3"
                    style={{ fontFamily: 'Syne', fontSize: '0.78rem', letterSpacing: '0.06em', color: svc.color }}>
                    Explore Service <ChevronRight size={14} />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {active && <ServiceModal service={active} onClose={() => setActive(null)} />}
      </AnimatePresence>
    </section>
  );
}
