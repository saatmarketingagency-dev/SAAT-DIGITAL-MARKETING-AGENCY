import { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Send, CheckCircle, AlertCircle, MapPin, Mail, Phone, MessageCircle } from 'lucide-react';

const services = [
  'Marketing Strategy',
  'Web Design & Development',
  'Website Handling',
  'Search Engine Optimization (SEO)',
  'Social Media Handling',
  'Graphic Design',
  'Brand Identity',
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', service: '', message: '' });
  const [status, setStatus] = useState('idle'); // idle | loading | success | error
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('loading');

    try {
      const res = await fetch('/.netlify/functions/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      if (res.ok) {
        setStatus('success');
        setForm({ name: '', email: '', phone: '', service: '', message: '' });
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }

    setTimeout(() => setStatus('idle'), 6000);
  };

  return (
    <section id="contact" className="relative py-28 px-6 overflow-hidden" style={{ zIndex: 1 }}>
      {/* Glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] opacity-10 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, #00E5A0 0%, transparent 70%)', filter: 'blur(80px)' }} />

      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-16"
        >
          <div className="section-label mb-4">Contact Us</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            Ready to{' '}
            <span className="gradient-text">Grow Your Business?</span>
          </h2>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', maxWidth: '480px', margin: '16px auto 0', fontSize: '1.05rem' }}>
            Reach out and we'll get back to you within 24 hours.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-10">
          {/* Info column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2 space-y-6"
          >
            {[
              { icon: MapPin, label: 'Location', value: 'Rawalpindi, Pakistan' },
              { icon: Mail, label: 'Email', value: 'saatmarketingagency@gmail.com', href: 'mailto:saatmarketingagency@gmail.com' },
              { icon: Phone, label: 'Phone', value: '+92 313 8586949', href: 'tel:+923138586949' },
            ].map(({ icon: Icon, label, value, href }) => (
              <div key={label} className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: 'rgba(0,229,160,0.08)', border: '1px solid rgba(0,229,160,0.2)' }}>
                  <Icon size={16} style={{ color: '#00E5A0' }} />
                </div>
                <div>
                  <div style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', marginBottom: '3px' }}>{label}</div>
                  {href ? (
                    <a href={href} style={{ fontFamily: 'DM Sans', color: '#EEEEF5', fontSize: '0.95rem', textDecoration: 'none' }}
                      className="hover:text-[#00E5A0] transition-colors">{value}</a>
                  ) : (
                    <span style={{ fontFamily: 'DM Sans', color: '#EEEEF5', fontSize: '0.95rem' }}>{value}</span>
                  )}
                </div>
              </div>
            ))}

            <div className="mt-6 pt-6" style={{ borderTop: '1px solid rgba(30,30,63,0.8)' }}>
              <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', fontSize: '0.9rem', marginBottom: '16px' }}>Or reach us instantly on WhatsApp:</p>
              <a
                href="https://wa.me/923138586949?text=Hi%20SAAT!%20I%20found%20you%20online%20and%20would%20like%20to%20discuss%20my%20project."
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex"
                style={{ background: 'linear-gradient(135deg, #25D366, #128C7E)' }}
              >
                <MessageCircle size={16} /> Chat on WhatsApp
              </a>
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="lg:col-span-3"
          >
            <form onSubmit={handleSubmit} className="card p-8 space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', display: 'block', marginBottom: '8px' }}>
                    FULL NAME *
                  </label>
                  <input
                    type="text" name="name" required value={form.name} onChange={handleChange}
                    placeholder="Your full name"
                    className="form-input"
                  />
                </div>
                <div>
                  <label style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', display: 'block', marginBottom: '8px' }}>
                    EMAIL *
                  </label>
                  <input
                    type="email" name="email" required value={form.email} onChange={handleChange}
                    placeholder="your@email.com"
                    className="form-input"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', display: 'block', marginBottom: '8px' }}>
                    PHONE
                  </label>
                  <input
                    type="tel" name="phone" value={form.phone} onChange={handleChange}
                    placeholder="+92 xxx xxxxxxx"
                    className="form-input"
                  />
                </div>
                <div>
                  <label style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', display: 'block', marginBottom: '8px' }}>
                    SERVICE REQUIRED
                  </label>
                  <select name="service" value={form.service} onChange={handleChange} className="form-input">
                    <option value="" disabled>Select a service...</option>
                    {services.map(s => <option key={s} value={s} style={{ background: '#0D0D1F' }}>{s}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label style={{ fontFamily: 'Syne', fontWeight: 600, fontSize: '0.8rem', color: '#7C7C9D', letterSpacing: '0.06em', display: 'block', marginBottom: '8px' }}>
                  YOUR MESSAGE
                </label>
                <textarea
                  name="message" rows={4} value={form.message} onChange={handleChange}
                  placeholder="Tell us about your project..."
                  className="form-input resize-none"
                />
              </div>

              {/* Status messages */}
              {status === 'success' && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-3 p-4 rounded-xl"
                  style={{ background: 'rgba(0,229,160,0.08)', border: '1px solid rgba(0,229,160,0.3)' }}>
                  <CheckCircle size={16} style={{ color: '#00E5A0' }} />
                  <span style={{ fontFamily: 'DM Sans', fontSize: '0.9rem', color: '#00E5A0' }}>
                    Message sent! We'll be in touch within 24 hours.
                  </span>
                </motion.div>
              )}
              {status === 'error' && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-3 p-4 rounded-xl"
                  style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.3)' }}>
                  <AlertCircle size={16} style={{ color: '#EF4444' }} />
                  <span style={{ fontFamily: 'DM Sans', fontSize: '0.9rem', color: '#EF4444' }}>
                    Something went wrong. Please try WhatsApp or email directly.
                  </span>
                </motion.div>
              )}

              <motion.button
                type="submit"
                disabled={status === 'loading' || status === 'success'}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full justify-center disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {status === 'loading' ? (
                  <span className="flex items-center gap-2">
                    <svg className="animate-spin" width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeDasharray="60" strokeDashoffset="20" />
                    </svg>
                    Sending...
                  </span>
                ) : (
                  <span className="flex items-center gap-2"><Send size={16} /> Send Message</span>
                )}
              </motion.button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
