import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { XCircle, CheckCircle, ArrowRight } from 'lucide-react';

const problems = [
  {
    icon: '🚫',
    title: 'No Online Customers',
    desc: 'People searching online cannot find your business. Your competitors are getting those customers instead of you.',
  },
  {
    icon: '📉',
    title: 'Weak Social Media',
    desc: 'Low engagement, inconsistent posts, and no strategy. Your Instagram or Facebook isn\'t bringing any business.',
  },
  {
    icon: '🌐',
    title: 'No Professional Website',
    desc: 'Customers who search for you find nothing — or worse, an outdated page that destroys trust before they even call.',
  },
];

const solutions = [
  {
    icon: '✅',
    title: 'Dominate Your Market',
    desc: 'We build your digital footprint so the right customers find you first on Google, social media, and everywhere online.',
  },
  {
    icon: '📲',
    title: 'Social Media That Works',
    desc: 'Professional content, consistent strategy, and community engagement that turns followers into paying customers.',
  },
  {
    icon: '🚀',
    title: 'Websites That Sell',
    desc: 'Fast, modern, and built to convert — your website becomes your best salesperson, working 24/7 to bring in leads.',
  },
];

function Card({ item, type, index }) {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.15 });
  const isProblem = type === 'problem';

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.12, ease: [0.16, 1, 0.3, 1] }}
      className="p-6 rounded-2xl relative overflow-hidden"
      style={{
        background: isProblem ? 'rgba(255,50,50,0.04)' : 'rgba(0,229,160,0.04)',
        border: `1px solid ${isProblem ? 'rgba(255,50,50,0.15)' : 'rgba(0,229,160,0.2)'}`,
        transition: 'all 0.4s ease',
      }}
    >
      <div className="flex items-start gap-4">
        <div className="text-3xl flex-shrink-0">{item.icon}</div>
        <div>
          <div className="flex items-center gap-2 mb-2">
            {isProblem
              ? <XCircle size={14} style={{ color: '#FF5555', flexShrink: 0 }} />
              : <CheckCircle size={14} style={{ color: '#00E5A0', flexShrink: 0 }} />}
            <h3 style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '1rem', color: '#EEEEF5' }}>
              {item.title}
            </h3>
          </div>
          <p style={{ fontFamily: 'DM Sans', fontSize: '0.9rem', color: '#7C7C9D', lineHeight: 1.65 }}>
            {item.desc}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

export default function Problem() {
  const { ref, inView } = useInView({ triggerOnce: true, threshold: 0.1 });

  return (
    <section id="problem" className="relative py-28 px-6" style={{ zIndex: 1 }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="section-label mb-4">The Problem</div>
          <h2 style={{ fontFamily: 'Syne', fontWeight: 800, fontSize: 'clamp(2rem,5vw,3.5rem)', color: '#EEEEF5', lineHeight: 1.1, letterSpacing: '-0.02em' }}>
            Is Your Business{' '}
            <span style={{ color: '#FF5555' }}>Struggling</span> Online?
          </h2>
          <p style={{ fontFamily: 'DM Sans', color: '#7C7C9D', maxWidth: '540px', margin: '16px auto 0', fontSize: '1.05rem', lineHeight: 1.7 }}>
            You're not alone. Most businesses in Pakistan and around the world face these same digital challenges — and they're costing real customers every day.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Problems */}
          <div className="space-y-4">
            <div className="section-label mb-6 flex items-center gap-2">
              <XCircle size={14} style={{ color: '#FF5555' }} />
              <span style={{ color: '#FF5555' }}>Current Reality</span>
            </div>
            {problems.map((p, i) => <Card key={i} item={p} type="problem" index={i} />)}
          </div>

          {/* Divider + Arrow */}
          <div className="space-y-4">
            <div className="section-label mb-6 flex items-center gap-2">
              <CheckCircle size={14} />
              SAAT Solves This
            </div>
            {solutions.map((s, i) => <Card key={i} item={s} type="solution" index={i} />)}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-16 text-center"
        >
          <button
            onClick={() => document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="btn-primary inline-flex"
          >
            Fix My Digital Presence <ArrowRight size={16} />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
