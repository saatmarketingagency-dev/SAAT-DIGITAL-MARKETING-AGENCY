import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Bot, User, Minimize2 } from 'lucide-react';

const SAAT_CONTEXT = `You are SAAT's AI assistant — a friendly, knowledgeable representative for SAAT Digital Marketing Agency based in Rawalpindi, Pakistan.

ABOUT SAAT:
- Premier digital marketing agency in Pakistan
- Founded by four industry specialists
- Based in Rawalpindi, Pakistan
- Email: saatmarketingagency@gmail.com
- Phone: +92 313 8586949
- Instagram: @saatmarketingagency
- TikTok: @saat4350

SERVICES OFFERED:
1. Marketing Strategy — Data-driven roadmaps, competitor analysis, KPI setting, channel strategy
2. Web Design & Development — Custom websites, responsive design, SEO-optimized, e-commerce
3. SEO — Technical audits, keyword research, link building, Google rankings
4. Social Media Handling — Content creation, scheduling, community management (Instagram, Facebook, TikTok)
5. Brand Identity & Graphic Design — Logo design, brand identity kits, motion graphics

KEY SELLING POINTS:
- 100% client satisfaction rate
- Fast delivery within agreed deadlines
- Affordable pricing — enterprise quality at accessible prices
- Modern, custom designs (no templates)
- Results-focused: everything is measured

HOW TO GET STARTED:
- Fill the contact form on the website
- WhatsApp: wa.me/923138586949
- Email: saatmarketingagency@gmail.com

Keep responses concise, helpful, and conversational. Always guide users toward contacting SAAT for their digital needs. Be enthusiastic but professional.`;

const suggestedQuestions = [
  'What services do you offer?',
  'How much does a website cost?',
  'How do I get started?',
  'What makes SAAT different?',
];

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hi! 👋 I\'m SAAT\'s AI assistant. I can answer any questions about our digital marketing services, pricing, or how we can help your business grow online. What would you like to know?',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 300);
  }, [open]);

  const sendMessage = async (text) => {
    const userMsg = text || input.trim();
    if (!userMsg || loading) return;
    setInput('');

    const newMessages = [...messages, { role: 'user', content: userMsg }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 500,
          system: SAAT_CONTEXT,
          messages: newMessages.map(m => ({ role: m.role, content: m.content })),
        }),
      });

      const data = await res.json();
      const reply = data.content?.[0]?.text || 'Sorry, I couldn\'t process that. Please contact us directly at saatmarketingagency@gmail.com.';
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I\'m having trouble connecting right now. Please reach us on WhatsApp at +92 313 8586949 or email saatmarketingagency@gmail.com.',
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating chat button */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.5, type: 'spring', stiffness: 300 }}
        onClick={() => setOpen(!open)}
        className="fixed z-50 flex items-center justify-center rounded-full shadow-2xl"
        style={{
          bottom: '100px',
          right: '24px',
          width: '52px',
          height: '52px',
          background: open ? 'rgba(30,30,63,0.9)' : 'linear-gradient(135deg, #00E5A0, #00B37E)',
          border: '1px solid rgba(0,229,160,0.4)',
          cursor: 'pointer',
          boxShadow: '0 8px 30px rgba(0,229,160,0.3)',
        }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Open chat"
      >
        <AnimatePresence mode="wait">
          {open ? (
            <motion.div key="close" initial={{ rotate: -90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: 90, opacity: 0 }} transition={{ duration: 0.2 }}>
              <X size={20} style={{ color: '#00E5A0' }} />
            </motion.div>
          ) : (
            <motion.div key="chat" initial={{ rotate: 90, opacity: 0 }} animate={{ rotate: 0, opacity: 1 }} exit={{ rotate: -90, opacity: 0 }} transition={{ duration: 0.2 }}>
              <Bot size={22} style={{ color: '#06060F' }} />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      {/* Tooltip */}
      {!open && (
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 2 }}
          className="fixed z-40 pointer-events-none"
          style={{ bottom: '116px', right: '86px' }}
        >
          <div className="px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap"
            style={{ background: 'rgba(17,17,40,0.95)', border: '1px solid rgba(0,229,160,0.3)', fontFamily: 'Syne', color: '#00E5A0', letterSpacing: '0.04em' }}>
            Ask AI anything ✨
          </div>
        </motion.div>
      )}

      {/* Chat window */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="fixed z-50 chatbot-window flex flex-col"
            style={{ bottom: '168px', right: '24px', width: 'min(380px, calc(100vw - 48px))', height: '500px' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4"
              style={{ borderBottom: '1px solid rgba(30,30,63,0.8)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                  style={{ background: 'linear-gradient(135deg, #00E5A0, #7B5EA7)' }}>
                  <Bot size={15} style={{ color: '#06060F' }} />
                </div>
                <div>
                  <div style={{ fontFamily: 'Syne', fontWeight: 700, fontSize: '0.9rem', color: '#EEEEF5' }}>SAAT Assistant</div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-green-400" style={{ animation: 'pulse-ring 2s ease infinite' }} />
                    <span style={{ fontFamily: 'DM Sans', fontSize: '0.72rem', color: '#7C7C9D' }}>Online</span>
                  </div>
                </div>
              </div>
              <button onClick={() => setOpen(false)} className="text-[#7C7C9D] hover:text-[#EEEEF5] transition-colors">
                <Minimize2 size={16} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className={`flex gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: msg.role === 'user' ? 'rgba(123,94,167,0.2)' : 'linear-gradient(135deg, #00E5A0, #00B37E)', border: `1px solid ${msg.role === 'user' ? 'rgba(123,94,167,0.4)' : 'rgba(0,229,160,0.4)'}` }}>
                    {msg.role === 'user'
                      ? <User size={13} style={{ color: '#7B5EA7' }} />
                      : <Bot size={13} style={{ color: '#06060F' }} />}
                  </div>
                  <div className="max-w-[80%] px-4 py-3 rounded-2xl"
                    style={{
                      background: msg.role === 'user' ? 'rgba(123,94,167,0.15)' : 'rgba(255,255,255,0.05)',
                      border: `1px solid ${msg.role === 'user' ? 'rgba(123,94,167,0.3)' : 'rgba(30,30,63,0.8)'}`,
                      fontFamily: 'DM Sans', fontSize: '0.87rem', color: '#EEEEF5', lineHeight: 1.6,
                      borderTopRightRadius: msg.role === 'user' ? '4px' : '18px',
                      borderTopLeftRadius: msg.role === 'user' ? '18px' : '4px',
                    }}>
                    {msg.content}
                  </div>
                </motion.div>
              ))}

              {loading && (
                <div className="flex gap-2">
                  <div className="w-7 h-7 rounded-full flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, #00E5A0, #00B37E)' }}>
                    <Bot size={13} style={{ color: '#06060F' }} />
                  </div>
                  <div className="px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-1.5"
                    style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(30,30,63,0.8)' }}>
                    {[0, 1, 2].map(j => (
                      <div key={j} className="w-1.5 h-1.5 rounded-full"
                        style={{ background: '#00E5A0', animation: `pulse 1s ease-in-out ${j * 0.2}s infinite alternate` }} />
                    ))}
                  </div>
                </div>
              )}

              {/* Suggestions – only show when there's just 1 message */}
              {messages.length === 1 && !loading && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {suggestedQuestions.map(q => (
                    <button key={q} onClick={() => sendMessage(q)}
                      className="px-3 py-1.5 rounded-full text-xs transition-all hover:border-[rgba(0,229,160,0.5)] hover:text-[#00E5A0]"
                      style={{ fontFamily: 'DM Sans', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(30,30,63,0.8)', color: '#7C7C9D', cursor: 'pointer' }}>
                      {q}
                    </button>
                  ))}
                </div>
              )}

              <div ref={bottomRef} />
            </div>

            {/* Input */}
            <div className="p-4" style={{ borderTop: '1px solid rgba(30,30,63,0.8)' }}>
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && sendMessage()}
                  placeholder="Ask about our services..."
                  className="form-input flex-1 py-3"
                  style={{ borderRadius: '12px', fontSize: '0.87rem' }}
                />
                <motion.button
                  onClick={() => sendMessage()}
                  disabled={!input.trim() || loading}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 disabled:opacity-40"
                  style={{ background: 'linear-gradient(135deg, #00E5A0, #00B37E)', cursor: 'pointer', border: 'none' }}
                >
                  <Send size={15} style={{ color: '#06060F' }} />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes pulse {
          from { opacity: 0.3; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1.2); }
        }
      `}</style>
    </>
  );
}
