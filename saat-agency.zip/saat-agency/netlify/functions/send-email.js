exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: 'Invalid JSON' };
  }

  const { name, email, phone, service, message } = body;

  if (!name || !email) {
    return { statusCode: 400, body: 'Missing required fields' };
  }

  const RESEND_API_KEY = process.env.RESEND_API_KEY || 're_Vz86nWTC_3ohMygQRSVgpf5EKqjMZ9D1g';

  const emailHtml = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: 'DM Sans', Arial, sans-serif; background: #06060F; color: #EEEEF5; margin: 0; padding: 0; }
    .container { max-width: 600px; margin: 0 auto; padding: 40px 20px; }
    .header { background: linear-gradient(135deg, #0D0D1F, #1E1E3F); border: 1px solid rgba(0,229,160,0.2); border-radius: 16px; padding: 32px; margin-bottom: 24px; text-align: center; }
    .logo { font-size: 28px; font-weight: 900; color: #EEEEF5; margin-bottom: 8px; }
    .badge { display: inline-block; background: rgba(0,229,160,0.1); border: 1px solid rgba(0,229,160,0.3); border-radius: 20px; padding: 4px 16px; font-size: 12px; color: #00E5A0; letter-spacing: 0.1em; }
    .card { background: #111128; border: 1px solid #1E1E3F; border-radius: 12px; padding: 24px; margin-bottom: 16px; }
    .label { font-size: 11px; color: #7C7C9D; letter-spacing: 0.1em; text-transform: uppercase; margin-bottom: 6px; }
    .value { font-size: 15px; color: #EEEEF5; }
    .footer { text-align: center; color: #7C7C9D; font-size: 12px; margin-top: 32px; }
    .accent { color: #00E5A0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo">SAAT</div>
      <div class="badge">NEW PROJECT INQUIRY</div>
      <p style="color:#7C7C9D; font-size:13px; margin-top:12px;">A new lead just came in through your website.</p>
    </div>

    <div class="card">
      <div class="label">Full Name</div>
      <div class="value">${name}</div>
    </div>

    <div class="card">
      <div class="label">Email Address</div>
      <div class="value"><a href="mailto:${email}" style="color:#00E5A0; text-decoration:none;">${email}</a></div>
    </div>

    ${phone ? `
    <div class="card">
      <div class="label">Contact Number</div>
      <div class="value"><a href="tel:${phone}" style="color:#00E5A0; text-decoration:none;">${phone}</a></div>
    </div>
    ` : ''}

    ${service ? `
    <div class="card">
      <div class="label">Service Required</div>
      <div class="value accent">${service}</div>
    </div>
    ` : ''}

    ${message ? `
    <div class="card">
      <div class="label">Message</div>
      <div class="value" style="line-height:1.7;">${message}</div>
    </div>
    ` : ''}

    <div style="text-align:center; margin-top:24px;">
      <a href="mailto:${email}" style="display:inline-block; background:linear-gradient(135deg,#00E5A0,#00B37E); color:#06060F; font-weight:700; border-radius:50px; padding:14px 32px; text-decoration:none; font-size:14px; letter-spacing:0.05em;">
        REPLY TO ${name.toUpperCase()}
      </a>
    </div>

    <div class="footer">
      <p>© 2026 SAAT Digital Marketing Agency — Rawalpindi, Pakistan</p>
      <p style="margin-top:4px;"><a href="https://saatmarketingagency.com" style="color:#00E5A0; text-decoration:none;">saatmarketingagency@gmail.com</a></p>
    </div>
  </div>
</body>
</html>
  `;

  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: 'SAAT Website <onboarding@resend.dev>',
        to: ['saatmarketingagency@gmail.com'],
        reply_to: email,
        subject: `🚀 New Inquiry from ${name}${service ? ` — ${service}` : ''}`,
        html: emailHtml,
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error('Resend error:', err);
      return { statusCode: 500, body: 'Email send failed' };
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ success: true }),
    };
  } catch (err) {
    console.error('Function error:', err);
    return { statusCode: 500, body: 'Internal server error' };
  }
};
